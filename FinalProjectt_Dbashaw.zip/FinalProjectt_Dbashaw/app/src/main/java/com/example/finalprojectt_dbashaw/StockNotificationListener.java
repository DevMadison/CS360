package com.example.finalprojectt_dbashaw;

public interface StockNotificationListener {
    void onStockNotification(String itemName);
}
