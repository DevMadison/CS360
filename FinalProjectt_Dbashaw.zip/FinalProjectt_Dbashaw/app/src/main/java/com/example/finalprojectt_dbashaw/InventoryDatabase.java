package com.example.finalprojectt_dbashaw;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "data_db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "items";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_STOCK_AMOUNT = "stock_amount";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private final StockNotificationListener stockNotificationListener;

    public InventoryDatabase(Context context, StockNotificationListener listener) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.stockNotificationListener = listener;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_STOCK_AMOUNT + " INTEGER, " +
                COLUMN_ITEM_NAME + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addItem(int stockAmount, String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_STOCK_AMOUNT, stockAmount);
        contentValues.put(COLUMN_ITEM_NAME, itemName);
        long result = db.insert(TABLE_NAME, null, contentValues);

        if (stockAmount == 0 && stockNotificationListener != null) {
            stockNotificationListener.onStockNotification(itemName);
        }

        return result != -1;
    }

    public boolean updateItemStock(int id, int newStockAmount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_STOCK_AMOUNT, newStockAmount);

        String itemName = getItemNameById(id); // Retrieve item name based on id
        int result = db.update(TABLE_NAME, contentValues, COLUMN_ID + "=?", new String[]{String.valueOf(id)});

        if (newStockAmount == 0 && stockNotificationListener != null) {
            stockNotificationListener.onStockNotification(itemName);
        }

        return result > 0;
    }

    private String getItemNameById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[]{COLUMN_ITEM_NAME}, COLUMN_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME));
            cursor.close();
            return itemName;
        }
        return null;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}
