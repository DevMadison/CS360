package com.example.finalprojectt_dbashaw;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;

public class MainActivity extends AppCompatActivity implements StockNotificationListener {
    private InventoryDatabase databaseHelper;
    private TableLayout dataGrid;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // interacts with listener interface
        databaseHelper = new InventoryDatabase(this, this);
        dataGrid = findViewById(R.id.data_grid);
        Button addDataButton = findViewById(R.id.add_data_button);
        Button sendSmsButton = findViewById(R.id.send_sms_button);

        loadGrid();

        addDataButton.setOnClickListener(v -> showAddDataDialog());
        sendSmsButton.setOnClickListener(v -> checkSmsPermissionAndSend());
    }

    @Override
    public void onStockNotification(String itemName) {
        String message = "Item count just dropped to 0.";
        sendSms("7274563348", message); // Fake number
    }

    private void loadGrid() {
        dataGrid.removeAllViews();
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") int stockAmount = cursor.getInt(cursor.getColumnIndex("stock_amount"));
                @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex("item_name"));

                @SuppressLint("InflateParams") TableRow row = (TableRow) LayoutInflater.from(this).inflate(R.layout.table_row, null);
                ((TextView) row.findViewById(R.id.stock_amount)).setText(String.valueOf(stockAmount));
                ((TextView) row.findViewById(R.id.item_name)).setText(itemName);

                Button editButton = row.findViewById(R.id.edit_button);
                editButton.setOnClickListener(v -> showEditItemDialog(id, stockAmount));

                Button deleteButton = row.findViewById(R.id.delete_button);
                deleteButton.setOnClickListener(v -> showDeleteConfirmationDialog(id));

                dataGrid.addView(row);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
// editing items in inventory
    private void showEditItemDialog(int id, int currentStockAmount) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Item");

        View view = LayoutInflater.from(this).inflate(R.layout.edit_stock, null);
        final EditText stockAmountEditText = view.findViewById(R.id.stock_amount_edit);

        stockAmountEditText.setText(String.valueOf(currentStockAmount)); //edits the count

        builder.setView(view);
        builder.setPositiveButton("Update", (dialog, which) -> { // final update
            int newStockAmount = Integer.parseInt(stockAmountEditText.getText().toString());
            if (databaseHelper.updateItemStock(id, newStockAmount)) {
                loadGrid();
            } else {
                Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show(); // in case of failure
            }
        });
        builder.setNegativeButton("Go back", null); // back out

        builder.create().show();
    }
// deleting items from inventory
    private void showDeleteConfirmationDialog(int id) {
        new AlertDialog.Builder(this)
                .setTitle("Confirm Deletion")
                .setMessage("This item will be deleted forever, do you want to proceed?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    if (databaseHelper.deleteItem(id)) {
                        loadGrid();
                    } else {
                        Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
// add inventory data
    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Data");

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_data, null);
        final EditText itemNameEditText = view.findViewById(R.id.item_name_edit);
        final EditText stockAmountEditText = view.findViewById(R.id.stock_amount_edit);

        builder.setView(view);
        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemName = itemNameEditText.getText().toString();
            String stockAmountStr = stockAmountEditText.getText().toString();

            if (itemName.isEmpty() || stockAmountStr.isEmpty()) {
                Toast.makeText(MainActivity.this, "Missing details.", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    int stockAmount = Integer.parseInt(stockAmountStr);
                    if (databaseHelper.addItem(stockAmount, itemName)) {
                        loadGrid();
                    } else {
                        Toast.makeText(MainActivity.this, "Failure to add item.", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Stock amount too low.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);

        builder.create().show();
    }

    private void checkSmsPermissionAndSend() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSms("7274563348", "SMS permission granted.");
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms("6888888888", "SMS permission granted.");
            } else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSms(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS message sent.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
        }
    }
}
