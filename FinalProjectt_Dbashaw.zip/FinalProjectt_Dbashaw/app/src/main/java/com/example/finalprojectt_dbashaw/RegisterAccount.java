package com.example.finalprojectt_dbashaw;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterAccount extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private MainDatabase databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_account);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        Button createAccountButton = findViewById(R.id.create_account_button);
        databaseHelper = new MainDatabase(this);

        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (databaseHelper.addUser(username, password)) {
                Toast.makeText(RegisterAccount.this, "Account regsitered..", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(RegisterAccount.this, "Account registration failed.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
